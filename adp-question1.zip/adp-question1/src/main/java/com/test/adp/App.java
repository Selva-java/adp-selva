package com.test.adp;


public class App 
{
	/*
	 * This is given if we need to run it as a commmand line program
	 */
    public static void main( String... args )
    {
        if(args.length < 1) {
        		System.out.println("An input argument is required");
        		return;
        }

    }
    
    /*
     * This function is tested using Junits
     */
    public static boolean process (String input) {
    	
        /*
         * Depending on the type of input different converters can be used.
         * I have implemented a LongConverter and IntegerConverter
         */
        //Converter converter = new IntegerConverter();
        Converter converter = new LongConverter();
        
        String bitsOfInput = converter.convert(input);
        
        boolean flagRev = isRevSame(bitsOfInput);
        
        System.out.println("bitsOfInput : " + bitsOfInput + " restult : " + flagRev);
        
        return flagRev;
        
    	
    }
    
    private static boolean isRevSame(String bitsOfInput)
    {   
        if(bitsOfInput.length() == 0 || bitsOfInput.length() == 1)
            return true; 
        
        if(bitsOfInput.charAt(0) == bitsOfInput.charAt(bitsOfInput.length()-1))
        		return isRevSame(bitsOfInput.substring(1, bitsOfInput.length()-1));
        else
        	    return false;
    }
}
