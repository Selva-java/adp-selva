package com.test.adp;

public interface Converter {
	public String convert(String input);
}
