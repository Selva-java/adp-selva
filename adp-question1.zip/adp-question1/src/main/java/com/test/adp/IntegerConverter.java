package com.test.adp;

public class IntegerConverter implements Converter {

	@Override
	public String convert(String input) {
    int output = 0;
        
    	try {	
    		output = Integer.parseInt(input);
    	}catch(NumberFormatException e) {
    		System.out.println("An integer should be passed as input. Value passed : " + input);
    		return "";
    	}
    
    return Integer.toBinaryString(output);

	}

}
