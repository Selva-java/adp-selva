package com.test.adp;

public class LongConverter implements Converter {

	@Override
	public String convert(String input) {
    long output = 0;
        
    	try {	
    		output = Long.parseLong(input);
    	}catch(NumberFormatException e) {
    		System.out.println("A long should be passed as input. Value passed : " + input);
    		return "";
    	}
    
    return Long.toBinaryString(output);

	}

}
