package com.adp.game.chess;

/*
 * Behavior is centralized and so a default implementation can be provided using defaultMethods.
 */
public interface CrossMover {

	default public Box crossMove(Box from, CrossDirection dir, int noOfPoistions) {
		Box destinationBox = new Box(from.getX(),from.getY(),from.getPiece(),from.getBoxColor());
		switch(dir) {
			case UPLEFT:
				/*calculate the destinationBox position*/
			case UPRIGHT:
				/*calculate the destinationBox position*/
			case DOWNLEFT:
				/*calculate the destinationBox position*/
			case DOWNRIGHT:
				/*calculate the destinationBox position*/
		}
		return destinationBox;
	};
	
	/*
	 * This is to be implemented by the piece as King can move only one step.
	 */
	Box specificCrossßMove(Box from,AxisDirection dir, int noOfPositions);

}
