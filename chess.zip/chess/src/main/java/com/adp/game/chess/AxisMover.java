package com.adp.game.chess;

public interface AxisMover {

	default public Box axisMove(Box from,AxisDirection dir, int noOfPositions) {
		Box destinationBox = new Box(from.getX(),from.getY(),from.getPiece(),from.getBoxColor());
		switch(dir) {
			case UP:
				/*calculate the destinationBox position*/
			case DOWN:
				/*calculate the destinationBox position*/
			case LEFT:
				/*calculate the destinationBox position*/
			case RIGHT:
				/*calculate the destinationBox position*/
		}
		return destinationBox;
	};
	
	/*
	 * This is to be implemented by the piece as King and Pawn can move only one step.
	 */
	Box specificAxisMove(Box from,AxisDirection dir, int noOfPositions);
	
}
