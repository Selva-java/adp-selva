package com.adp.game.chess;

public enum CrossDirection {
	UPLEFT,UPRIGHT,DOWNLEFT,DOWNRIGHT;
}
