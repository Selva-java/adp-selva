package com.adp.game.chess;

public enum Color {

	BLACK,WHITE;
}
