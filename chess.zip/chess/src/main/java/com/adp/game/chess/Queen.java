package com.adp.game.chess;

/*
 * Inherits data from piece and behavior from the two movers.
 */
public class Queen extends Piece implements CrossMover,AxisMover{



	@Override
	public boolean isValidMove(Box from, Box to) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Box specificAxisMove(Box from, AxisDirection dir, int noOfPositions) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Box specificCrossßMove(Box from, AxisDirection dir, int noOfPositions) {
		// TODO Auto-generated method stub
		return null;
	}

}
