package com.adp.game.chess;

public enum AxisDirection {
	UP,DOWN,LEFT,RIGHT;
}
