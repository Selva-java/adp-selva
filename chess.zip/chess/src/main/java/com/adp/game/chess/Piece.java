package com.adp.game.chess;

public abstract class Piece {

	/*
	 * data on the piece is encapsulated.
	 */
	private Box currentLocation;
	private Color playerColor;
	
	/*
	 * This method implementation is to be provided by the implementing class
	 */
	public abstract boolean isValidMove(Box from,Box to);
	
	public Box getCurrentLocation() {
		return currentLocation;
	}
	public void setCurrentLocation(Box currentLocation) {
		this.currentLocation = currentLocation;
	}
	public Color getPlayerColor() {
		return playerColor;
	}
	public void setPlayerColor(Color playerColor) {
		this.playerColor = playerColor;
	}	
	
	

}
