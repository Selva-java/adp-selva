package com.adp.game.chess;

public class Rook extends Piece implements AxisMover{


	@Override
	public boolean isValidMove(Box from, Box to) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Box specificAxisMove(Box from, AxisDirection dir, int noOfPositions) {
		// TODO Auto-generated method stub
		return null;
	}

}
