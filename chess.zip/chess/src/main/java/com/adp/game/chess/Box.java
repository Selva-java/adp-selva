package com.adp.game.chess;

public class Box {
	private int x,y;
	private Piece piece;
	private Color boxColor;
	
	public void clearPeice() {
		
	}
	public Box(int x, int y, Piece piece, Color boxColor) {
		super();
		this.x = x;
		this.y = y;
		this.piece = piece;
		this.boxColor = boxColor;
	}
	public int getX() {
		return x;
	}
	public void setX(int x) {
		this.x = x;
	}
	public int getY() {
		return y;
	}
	public void setY(int y) {
		this.y = y;
	}
	public Piece getPiece() {
		return piece;
	}
	public void setPiece(Piece piece) {
		this.piece = piece;
	}
	public Color getBoxColor() {
		return boxColor;
	}
	public void setBoxColor(Color boxColor) {
		this.boxColor = boxColor;
	}	
	
	
	
}
