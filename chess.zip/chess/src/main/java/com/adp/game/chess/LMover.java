package com.adp.game.chess;

public interface LMover {

	default public Box lMove(Box from,AxisDirection axisdir, CrossDirection crossdir) {
		
		Box destinationBox = new Box(from.getX(),from.getY(),from.getPiece(),from.getBoxColor());
		/*
		 * Code for moving in L direction based on input
		 */
				
		return destinationBox;
	}
}

