package com.adp.game.chess;

/*
 * Inherits data from piece and behavior from the Lmover.
 */
public class Horse extends Piece implements LMover{


	@Override
	public boolean isValidMove(Box from, Box to) {
		// TODO Auto-generated method stub
		return false;
	}

}