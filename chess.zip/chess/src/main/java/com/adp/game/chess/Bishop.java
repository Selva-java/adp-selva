package com.adp.game.chess;

/*
 * Inherits data from piece and behavior from the CrossMover.
 */
public class Bishop extends Piece implements CrossMover{


	@Override
	public boolean isValidMove(Box from, Box to) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Box specificCrossßMove(Box from, AxisDirection dir, int noOfPositions) {
		// TODO Auto-generated method stub
		return null;
	}

}
