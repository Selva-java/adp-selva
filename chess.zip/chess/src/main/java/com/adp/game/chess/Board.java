package com.adp.game.chess;

public class Board {
	private Box[][] totalBoxes  = new Box[8][8];
	
	public void initialize() {
		 /*
		  * Code to initialize the game with 16 pieces for each player
		  * A sample initialization for the first piece  in both the players side is gvien below.
		  */
		
		totalBoxes[0][0] = new Box(0,0, new Rook(),Color.WHITE);
		totalBoxes[0][8] = new Box(0,0, new Rook(),Color.BLACK);
	}
	
	/*
	 * This method implementation is to be provided by the implementing class
	 */
	public boolean move(Box from,Box to) {
		from.getPiece().isValidMove(from, to);
		
		totalBoxes[to.getX()][to.getY()].setPiece(from.getPiece());
				
		totalBoxes[from.getX()][from.getY()].clearPeice(); 
		
		/*
		 * if everything is successful the method return true .
		 * Other validations are to be implemented.
		 */
		return true;
		
	};
}

