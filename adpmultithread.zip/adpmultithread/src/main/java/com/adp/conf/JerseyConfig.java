package com.adp.conf;

import org.glassfish.jersey.server.ResourceConfig;
import org.springframework.context.annotation.Configuration;

import com.adp.restcontroller.ExecutorServiceController;

@Configuration
public class JerseyConfig extends ResourceConfig {

    public JerseyConfig() {

        packages("com.adp.restcontroller");
        //register(ExecutorServiceController.class);

    }
}