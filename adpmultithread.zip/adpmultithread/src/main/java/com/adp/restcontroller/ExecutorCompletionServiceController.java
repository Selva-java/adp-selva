package com.adp.restcontroller;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorCompletionService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;

import com.adp.common.FormDto;
import com.adp.common.ParticipantCallable;
import com.adp.common.ParticipantDto;
import com.adp.common.PlanCallable;
import com.adp.common.PlanDto;

@Component
@Path("/executorcompletionservice")
/*
 * This implementation could be potentially faster than ExecutorService in case the first call takes longer than the second call.
 * In the ExecutorCompletionService it takes and processes from queue whichever call has completed using "take" method.
 */
public class ExecutorCompletionServiceController {

	@GET
	@Produces(MediaType.APPLICATION_JSON_VALUE)
	public FormDto partcipantAndPlanData() throws InterruptedException {
		
		/*
		 * In our implementation instead of a executorservice for each service call, we had an ThreadPoolTaskExecutor (with a fixed thread pool size)
		 * common for the application. Here i have used a cachedthread pool (with default 1 minute cache).	 
		 */
        ExecutorService executorService = Executors.newCachedThreadPool();
        
        ExecutorCompletionService<Object> executorCompletionService = new ExecutorCompletionService<>(executorService);
        
        executorCompletionService.submit(new ParticipantCallable());
        executorCompletionService.submit(new PlanCallable());
        
        Object obj;
        ParticipantDto participantDto = null;
        PlanDto planDto = null;
   
        for(int i=0;i<2;i++) {
	        
	        try {
	        	
	        		obj = executorCompletionService.take().get();
	        		
	        		if(obj.getClass() == ParticipantDto.class)
	        			participantDto = (ParticipantDto)obj;
	        		
	        		if(obj.getClass() == PlanDto.class)
	        			planDto = (PlanDto)obj;
	        		
			} catch (ExecutionException e) {
				/*
				 * Exception hanlding code here.
				 */
				System.out.println("Exception in calling participant service");
			}
        }
        

        
        executorService.shutdown();       
        
        return new FormDto(participantDto,  planDto);

	}
}
