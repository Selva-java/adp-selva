package com.adp.restcontroller;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;

import com.adp.common.FormDto;
import com.adp.common.ParticipantCallable;
import com.adp.common.ParticipantDto;
import com.adp.common.PlanCallable;
import com.adp.common.PlanDto;

@Component
@Path("/executorservice")
public class ExecutorServiceController {

	
	@GET
	@Produces(MediaType.APPLICATION_JSON_VALUE)
	public FormDto partcipantAndPlanData() throws InterruptedException {
		
		/*
		 * In our implementation instead of a executorservice for each service call, we had an ThreadPoolTaskExecutor (with a fixed thread pool size)
		 * common for the application. Here i have used a cachedthread pool (with default 1 minute cache).	 
		 */
        ExecutorService executorService = Executors.newCachedThreadPool();
        
        Future<Object> participantFuture = executorService.submit(new ParticipantCallable());
        Future<Object> planFuture = executorService.submit(new PlanCallable());
        
        PlanDto planDto = null;
        ParticipantDto participantDto = null;
        
        /*
         * This waits on the first service to complete even if second service returned and completed successfully;
         */
        
        

        try {
			participantDto =  (ParticipantDto)participantFuture.get(20,TimeUnit.SECONDS);
		} catch (TimeoutException  | ExecutionException e) {
			/*
			 * Exception hanlding code here.
			 */
			System.out.println("Exception in calling participant service");
		}
        
        try {
			 planDto =  (PlanDto)planFuture.get(20,TimeUnit.SECONDS);
		} catch (ExecutionException | TimeoutException e) {
			/*
			 * Exception hanlding code here.
			 */
			System.out.println("Exception in calling plan service");
		}
        
        executorService.shutdown();  
        
        return new FormDto(participantDto,  planDto);
	}
}
