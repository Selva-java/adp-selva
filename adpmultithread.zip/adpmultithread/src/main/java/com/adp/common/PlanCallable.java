package com.adp.common;

import java.util.concurrent.Callable;

public class PlanCallable implements Callable<Object> {

	/*
	 * For being able to used with ExecutorCompletionService the return type is made uniformly as Object
	 */
	public Object call() throws Exception {
		Thread.sleep(10000);
		/*
		 * Was calling a rest web service using restTemplate
		 */
		System.out.println("Plan thread about to complete");
		return new PlanDto("1","401K");
	}

}
