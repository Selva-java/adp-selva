package com.adp.common;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class FormDto {

	ParticipantDto participantDto;
	PlanDto planDto;
	public ParticipantDto getParticipantDto() {
		return participantDto;
	}
	public void setParticipantDto(ParticipantDto participantDto) {
		this.participantDto = participantDto;
	}
	public PlanDto getPlanDto() {
		return planDto;
	}
	public void setPlanDto(PlanDto planDto) {
		this.planDto = planDto;
	}
	public FormDto(ParticipantDto participantDto, PlanDto planDto) {
		super();
		this.participantDto = participantDto;
		this.planDto = planDto;
	}
	
	
}
