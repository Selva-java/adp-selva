package com.adp.common;

import java.util.concurrent.Callable;

public class ParticipantCallable implements Callable<Object>{

	/*
	 * For being able to used with ExecutorCompletionService the return type is made uniformly as Object
	 */
	public Object call() throws Exception {
	
		Thread.sleep(15000);
		/*
		 * Was calling a rest web service using restTemplate
		 */
		System.out.println("Participant thread about to complete");
		//int x =1/0;
		return new ParticipantDto("John","Smith","1");
	}

}
