package com.adp.common;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorCompletionService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

public class App 
{
    public static void main( String[] args ) throws InterruptedException
    {
    		//usingExecutorService();
    		usingExecutionCompletionService();
    }
    
    private static void usingExecutorService() throws InterruptedException
    {
        ExecutorService executorService = Executors.newCachedThreadPool();
        
        Future<Object> participantFuture = executorService.submit(new ParticipantCallable());
        Future<Object> planFuture = executorService.submit(new PlanCallable());
        
        /*
         * This waits on the first service to complete even if second service returned and completed successfully;
         */

        try {
			ParticipantDto participantDto =  (ParticipantDto)participantFuture.get(5,TimeUnit.SECONDS);
		} catch (TimeoutException  | ExecutionException e) {
			/*
			 * Exception hanlding code here.
			 */
			System.out.println("Exception in calling participant service");
		}
        
        try {
			PlanDto planDto =  (PlanDto)planFuture.get(5,TimeUnit.SECONDS);
		} catch (ExecutionException | TimeoutException e) {
			/*
			 * Exception hanlding code here.
			 */
			System.out.println("Exception in calling plan service");
		}
        
        executorService.shutdown();   
    }
    
    private static void usingExecutionCompletionService() throws InterruptedException
    {

        ExecutorService executorService = Executors.newCachedThreadPool();
        
        ExecutorCompletionService<Object> executorCompletionService = new ExecutorCompletionService<>(executorService);
        
        executorCompletionService.submit(new ParticipantCallable());
        executorCompletionService.submit(new PlanCallable());
        
        Object obj;
        ParticipantDto participantDto = null;
        PlanDto planDto = null;
   
        for(int i=0;i<2;i++) {
	        
	        try {
	        	
	        		obj = executorCompletionService.take().get();
	        		
	        		if(obj.getClass() == ParticipantDto.class)
	        			participantDto = (ParticipantDto)obj;
	        		
	        		if(obj.getClass() == PlanDto.class)
	        			planDto = (PlanDto)obj;
	        		
			} catch (ExecutionException e) {
				/*
				 * Exception hanlding code here.
				 */
				System.out.println("Exception in calling participant service");
			}
        }
        

        
        executorService.shutdown();        
        
    }
    
}

