package com.adp.common;

public class PlanDto {

	String participantId;
	String planName;
	
	public PlanDto(String participantId, String planName) {
		super();
		this.participantId = participantId;
		this.planName = planName;
	}
	public String getParticipantId() {
		return participantId;
	}
	public void setParticipantId(String participantId) {
		this.participantId = participantId;
	}
	public String getPlanName() {
		return planName;
	}
	public void setPlanName(String planName) {
		this.planName = planName;
	}
	
	
}
